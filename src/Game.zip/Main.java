import RegisterMenu.RegisterMenu;
public class Main {
    public static void main(String[] args) {
        new RegisterMenu().run();
    }
}
