package Scan;

import java.util.Scanner;

public class Scan {
    public static Scanner scanner = new Scanner(System.in);
}
